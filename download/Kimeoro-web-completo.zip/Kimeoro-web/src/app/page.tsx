"use client";

import { useEffect, useRef, useState, useMemo } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import {
  Globe,
  ShoppingBag,
  Clock,
  AlertTriangle,
  Users,
  Server,
  Heart,
  ChevronDown,
  Sparkles,
  Shield,
  HardDrive,
  ArrowRight,
  ExternalLink,
  Menu,
  X,
  HandCoins,
  TrendingUp,
  MessageCircle,
  Scale,
  Bot,
  Zap,
  Gamepad2,
} from "lucide-react";
import Image from "next/image";

/* ─── deterministic pseudo-random (seeded) ─── */
function seededValues(count: number, seed = 42) {
  const vals: number[] = [];
  let s = seed;
  for (let i = 0; i < count; i++) {
    s = (s * 16807) % 2147483647;
    vals.push((s - 1) / 2147483646);
  }
  return vals;
}

/* ─── Starfield Background ─── */
function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    const stars: { x: number; y: number; r: number; speed: number; opacity: number; twinkleSpeed: number }[] = [];
    const shootingStars: { x: number; y: number; len: number; speed: number; opacity: number; angle: number; life: number; maxLife: number }[] = [];

    function resize() {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < 250; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.3,
        speed: Math.random() * 0.02 + 0.005,
        opacity: Math.random(),
        twinkleSpeed: Math.random() * 0.02 + 0.005,
      });
    }

    function spawnShootingStar() {
      if (shootingStars.length < 2 && Math.random() < 0.008) {
        shootingStars.push({
          x: Math.random() * canvas.width * 0.8 + canvas.width * 0.2,
          y: Math.random() * canvas.height * 0.3,
          len: Math.random() * 80 + 40,
          speed: Math.random() * 4 + 3,
          opacity: 1,
          angle: (Math.PI / 4) + Math.random() * 0.3,
          life: 0,
          maxLife: Math.random() * 40 + 30,
        });
      }
    }

    function animate() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const star of stars) {
        star.opacity += star.twinkleSpeed;
        if (star.opacity >= 1 || star.opacity <= 0.1) star.twinkleSpeed *= -1;
        star.opacity = Math.max(0.1, Math.min(1, star.opacity));

        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(200, 180, 255, ${star.opacity * 0.8})`;
        ctx.fill();

        if (star.r > 1) {
          ctx.beginPath();
          ctx.arc(star.x, star.y, star.r * 3, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(124, 58, 237, ${star.opacity * 0.15})`;
          ctx.fill();
        }
      }

      spawnShootingStar();
      for (let i = shootingStars.length - 1; i >= 0; i--) {
        const ss = shootingStars[i];
        ss.life++;
        ss.x -= Math.cos(ss.angle) * ss.speed;
        ss.y += Math.sin(ss.angle) * ss.speed;
        ss.opacity = 1 - (ss.life / ss.maxLife);

        if (ss.life >= ss.maxLife) {
          shootingStars.splice(i, 1);
          continue;
        }

        const tailX = ss.x + Math.cos(ss.angle) * ss.len;
        const tailY = ss.y - Math.sin(ss.angle) * ss.len;

        const gradient = ctx.createLinearGradient(ss.x, ss.y, tailX, tailY);
        gradient.addColorStop(0, `rgba(255, 255, 255, ${ss.opacity})`);
        gradient.addColorStop(1, `rgba(124, 58, 237, 0)`);

        ctx.beginPath();
        ctx.moveTo(ss.x, ss.y);
        ctx.lineTo(tailX, tailY);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(ss.x, ss.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${ss.opacity})`;
        ctx.fill();
      }

      animId = requestAnimationFrame(animate);
    }
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 pointer-events-none"
      style={{ background: "linear-gradient(180deg, #050510 0%, #0a0a2e 40%, #0f0f3a 70%, #050510 100%)" }}
    />
  );
}

/* ─── Animated Section Wrapper ─── */
function AnimatedSection({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 60 }}
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ─── Floating Particles (SSR-safe with seeded values) ─── */
function FloatingParticles() {
  const particles = useMemo(() => {
    const rands = seededValues(80, 7);
    return Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: rands[i * 4] * 100,
      y: rands[i * 4 + 1] * 100,
      size: rands[i * 4 + 2] * 4 + 2,
      opacity: rands[i * 4 + 3] * 0.3 + 0.1,
      duration: rands[i * 4 + 2] * 10 + 10,
      delay: rands[i * 4 + 3] * 5,
    }));
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: `rgba(124, 58, 237, ${p.opacity})`,
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-10, 10, -10],
            opacity: [0.2, 0.6, 0.2],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

/* ─── Navbar ─── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const navLinks = [
    { label: "Inicio", href: "#hero" },
    { label: "Características", href: "#features" },
    { label: "Panel", href: "#dashboard" },
    { label: "Servidores", href: "#servers" },
  ];

  const externalLinks = [
    {
      label: "Discord",
      href: "https://discord.gg/kimeoro",
      icon: <MessageCircle className="w-4 h-4" />,
      className: "text-gray-300 hover:text-indigo-400",
    },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-strong shadow-lg shadow-purple-900/20" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <motion.div
            className="flex items-center gap-3"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <Image
              src="/galaxity-logo.png"
              alt="Kimeoro Bot Logo"
              width={40}
              height={40}
              className="rounded-lg"
            />
            <span className="text-lg sm:text-xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Kimeoro Bot
            </span>
          </motion.div>

          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm text-gray-300 hover:text-white rounded-lg hover:bg-white/5 transition-all duration-300"
              >
                {link.label}
              </a>
            ))}
            {externalLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition-all duration-300 flex items-center gap-2 ${link.className}`}
              >
                {link.icon}
                {link.label}
              </a>
            ))}
            <a
              href="/dashboard"
              className="ml-2 px-5 py-2 text-sm font-semibold rounded-lg bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white transition-all duration-300 flex items-center gap-2 shadow-lg shadow-purple-900/30"
            >
              <Bot className="w-4 h-4" />
              Panel
            </a>
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 text-gray-300 hover:text-white"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden overflow-hidden glass-strong rounded-xl mb-4"
            >
              <div className="p-4 flex flex-col gap-2">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="px-4 py-3 text-gray-300 hover:text-white rounded-lg hover:bg-white/5 transition-all"
                  >
                    {link.label}
                  </a>
                ))}
                {externalLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setMobileOpen(false)}
                    className={`px-4 py-3 rounded-lg hover:bg-white/5 transition-all flex items-center gap-2 ${link.className}`}
                  >
                    {link.icon}
                    {link.label}
                  </a>
                ))}
                <a
                  href="/dashboard"
                  onClick={() => setMobileOpen(false)}
                  className="px-4 py-3 font-semibold rounded-lg bg-gradient-to-r from-purple-600 to-cyan-600 text-white text-center flex items-center justify-center gap-2"
                >
                  <Bot className="w-4 h-4" />
                  Panel
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
}

/* ─── Hero Section ─── */
function HeroSection() {
  const [count, setCount] = useState(0);
  const targetCount = 42;

  useEffect(() => {
    let current = 0;
    const interval = setInterval(() => {
      current += 1;
      setCount(current);
      if (current >= targetCount) clearInterval(interval);
    }, 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <FloatingParticles />

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-800/5 rounded-full blur-3xl" />

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 1, type: "spring", stiffness: 100 }}
          className="mb-8 inline-block"
        >
          <div className="relative">
            <div className="absolute inset-0 bg-purple-500/20 rounded-2xl blur-xl scale-110" />
            <Image
              src="/galaxity-logo.png"
              alt="Kimeoro Bot"
              width={120}
              height={120}
              className="relative rounded-2xl animate-pulse-glow"
            />
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-5xl sm:text-7xl md:text-8xl font-extrabold mb-6"
        >
          <span className="bg-gradient-to-r from-purple-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent animate-gradient bg-[length:200%_200%]">
            Kimeoro Bot
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-xl sm:text-2xl text-gray-300 mb-4 font-medium"
        >
          Panel de Administración para Discord
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex items-center justify-center gap-2 text-gray-400 mb-8"
        >
          <Bot className="w-4 h-4 text-purple-400" />
          <span>Gestionando</span>
          <span className="text-purple-400 font-semibold">{count}+ servidores</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="glass rounded-2xl p-6 sm:p-8 inline-block mb-10 max-w-lg mx-auto"
        >
          <div className="flex items-center justify-center gap-3 mb-3">
            <Sparkles className="w-6 h-6 text-purple-400" />
            <h3 className="text-xl font-bold text-purple-400">¡Bienvenido al Futuro!</h3>
          </div>
          <p className="text-gray-300 text-sm sm:text-base">
            El panel de administración más completo para tu bot de Discord.
            <br />
            <span className="text-cyan-300 font-semibold">
              Economía, Tickets, Comandos y mucho más.
            </span>
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="/dashboard"
            className="group px-8 py-4 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-bold text-lg transition-all duration-300 shadow-lg shadow-purple-900/40 hover:shadow-purple-900/60 flex items-center gap-3"
          >
            <Zap className="w-5 h-5" />
            Acceder al Panel
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#features"
            className="px-8 py-4 rounded-xl glass hover:bg-white/10 text-white font-bold text-lg transition-all duration-300 flex items-center gap-3"
          >
            <Gamepad2 className="w-5 h-5 text-purple-400" />
            Ver Características
          </a>
        </motion.div>

        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="mt-16"
        >
          <ChevronDown className="w-8 h-8 text-purple-400/60 mx-auto" />
        </motion.div>
      </div>
    </section>
  );
}

/* ─── Features Section ─── */
function FeaturesSection() {
  const features = [
    {
      title: "Gestión de Servidores",
      description: "Administra todos tus servidores de Discord desde un solo lugar. Monitorea estadísticas en tiempo real.",
      icon: <Server className="w-8 h-8" />,
      gradient: "from-purple-600 to-violet-600",
    },
    {
      title: "Sistema de Economía",
      description: "Economía completa con moneda personalizable, transferencias, tops de usuarios y más.",
      icon: <HandCoins className="w-8 h-8" />,
      gradient: "from-emerald-600 to-green-600",
    },
    {
      title: "Sistema de Tickets",
      description: "Soporte al cliente integrado con tickets, categorías y seguimiento de problemas.",
      icon: <MessageCircle className="w-8 h-8" />,
      gradient: "from-blue-600 to-cyan-600",
    },
    {
      title: "Comandos Personalizados",
      description: "Crea y gestiona comandos custom para tu bot sin necesidad de programar.",
      icon: <Zap className="w-8 h-8" />,
      gradient: "from-amber-600 to-orange-600",
    },
  ];

  return (
    <section id="features" className="relative py-24 sm:py-32">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-purple-600/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        <AnimatedSection className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-300 font-medium">Características Principales</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold mb-4">
            <span className="bg-gradient-to-r from-purple-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
              Todo lo que necesitas
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Un panel completo con todas las herramientas para gestionar tu comunidad de Discord
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <AnimatedSection key={i} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -8, scale: 1.02 }}
                className="glass-strong rounded-2xl p-6 h-full group relative overflow-hidden"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                
                <div className="relative">
                  <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${feature.gradient} text-white mb-4 group-hover:scale-110 transition-transform shadow-lg`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                </div>
              </motion.div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Dashboard Preview Section ─── */
function DashboardSection() {
  return (
    <section id="dashboard" className="relative py-24 sm:py-32">
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <AnimatedSection>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-300 font-medium">Panel de Control</span>
            </div>
            <h2 className="text-4xl sm:text-5xl font-extrabold mb-6">
              <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Tu Dashboard
              </span>
            </h2>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              Accede a un panel de administración moderno e intuitivo. 
              Gestiona tu bot, monitorea estadísticas y controla todo desde un solo lugar.
            </p>

            <div className="space-y-4">
              {[
                "Vista general de todos tus servidores",
                "Estadísticas de economía en tiempo real",
                "Gestión de tickets y soporte",
                "Configuración de comandos personalizados",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-gray-300">
                  <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                    <svg className="w-3 h-3 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <span>{item}</span>
                </div>
              ))}
            </div>

            <a
              href="/dashboard"
              className="mt-8 inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-bold text-lg transition-all duration-300 shadow-lg shadow-cyan-900/30 hover:shadow-cyan-900/50"
            >
              Acceder al Panel
              <ArrowRight className="w-5 h-5" />
            </a>
          </AnimatedSection>

          <AnimatedSection delay={0.2}>
            <div className="glass-strong rounded-2xl p-2 shadow-2xl shadow-purple-900/20">
              <div className="bg-[#0a0a1a] rounded-xl p-6">
                <div className="flex items-center gap-3 mb-6 pb-6 border-b border-purple-500/20">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                    K
                  </div>
                  <div>
                    <p className="text-white font-semibold">Kimeoro Dashboard</p>
                    <p className="text-xs text-gray-400">Panel de Administración</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {[
                    { label: "Servidores", value: "5", color: "purple" },
                    { label: "Usuarios", value: "1.2K", color: "cyan" },
                    { label: "Tickets", value: "23", color: "green" },
                    { label: "Comandos", value: "45", color: "amber" },
                  ].map((stat, i) => (
                    <div key={i} className="bg-white/5 rounded-xl p-4">
                      <p className="text-gray-400 text-xs mb-1">{stat.label}</p>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                      <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <Server className="w-4 h-4 text-purple-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-white text-sm font-medium">Servidor {i}</p>
                        <p className="text-gray-500 text-xs">{Math.floor(Math.random() * 500) + 100} miembros</p>
                      </div>
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

/* ─── Servers Section ─── */
function ServersSection() {
  const servers = [
    { name: "Comunidad Principal", members: "2,543", status: "online", icon: "🎮" },
    { name: "Staff Team", members: "45", status: "online", icon: "💎" },
    { name: "VIP Lounge", members: "892", status: "online", icon: "⭐" },
    { name: "Gaming Hub", members: "1,234", status: "online", icon: "🎯" },
    { name: "Music Zone", members: "567", status: "online", icon: "🎵" },
    { name: "Giveaways", members: "3,421", status: "online", icon: "🎁" },
  ];

  return (
    <section id="servers" className="relative py-24 sm:py-32">
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        <AnimatedSection className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Server className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-300 font-medium">Nuestros Servidores</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold mb-4">
            <span className="bg-gradient-to-r from-purple-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
              Servidores Activos
            </span>
          </h2>
          <p class="text-gray-400 text-lg max-w-2xl mx-auto">
            Únete a nuestra creciente comunidad de Discord
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {servers.map((server, i) => (
            <AnimatedSection key={i} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -8, scale: 1.02 }}
                className="glass-strong rounded-2xl p-6 cursor-pointer group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/0 to-cyan-600/0 group-hover:from-purple-600/10 group-hover:to-cyan-600/10 transition-opacity duration-300" />
                
                <div className="relative">
                  <div className="text-4xl mb-4 group-hover:scale-125 group-hover:rotate-12 transition-transform duration-300">
                    {server.icon}
                  </div>
                  <h3 className="font-bold text-white text-lg mb-2">{server.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                    <Users className="w-4 h-4" />
                    {server.members} miembros
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-lg shadow-green-500/50" />
                    <span className="text-xs text-green-400 font-medium">En línea</span>
                  </div>
                </div>
              </motion.div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Mobile Servers Horizontal Scroll Section ─── */
function MobileServersSection() {
  const mobileServers = [
    { name: "Principal", icon: "🎮", members: "2.5K" },
    { name: "VIP", icon: "⭐", members: "892" },
    { name: "Gaming", icon: "🎯", members: "1.2K" },
    { name: "Música", icon: "🎵", members: "567" },
    { name: "Sorteos", icon: "🎁", members: "3.4K" },
    { name: "Staff", icon: "💎", members: "45" },
    { name: "Dev", icon: "💻", members: "123" },
    { name: "Chill", icon: "😎", members: "789" },
    { name: "RPG", icon: "⚔️", members: "456" },
    { name: "Art", icon: "🎨", members: "234" },
  ];

  return (
    <section className="relative py-12 border-t border-purple-500/10">
      <div className="max-w-full px-4 sm:px-6">
        <div className="flex items-center gap-3 mb-6">
          <Server className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-bold text-white">Todos los Servidores</h3>
          <span className="text-xs text-gray-500 ml-auto">Desliza →</span>
        </div>
        
        {/* Horizontal Scroll Container for Mobile */}
        <div className="overflow-x-auto pb-4 -mx-4 px-4 scrollbar-thin scrollbar-thumb-purple-500/30 scrollbar-track-transparent">
          <div className="flex gap-4" style={{ minWidth: "max-content" }}>
            {mobileServers.map((server, i) => (
              <a
                key={i}
                href="#"
                className="flex-shrink-0 glass rounded-xl p-4 w-36 hover:bg-white/10 transition-all duration-300 group"
              >
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform">
                  {server.icon}
                </div>
                <p className="text-white text-sm font-medium truncate">{server.name}</p>
                <p className="text-gray-500 text-xs">{server.members} miembros</p>
              </a>
            ))}
            
            {/* "Ver más" card at the end */}
            <a
              href="#servers"
              className="flex-shrink-0 glass rounded-xl p-4 w-36 flex flex-col items-center justify-center hover:bg-purple-500/20 transition-all duration-300 group"
            >
              <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center mb-2 group-hover:bg-purple-500/30 transition-colors">
                <ArrowRight className="w-5 h-5 text-purple-400 group-hover:translate-x-1 transition-transform" />
              </div>
              <p className="text-purple-400 text-sm font-medium">Ver todos</p>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Footer ─── */
function Footer() {
  return (
    <footer className="relative pt-20 pb-10">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[200px] bg-purple-900/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-strong rounded-2xl p-8 sm:p-12">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Image
                  src="/galaxity-logo.png"
                  alt="Kimeoro Bot"
                  width={40}
                  height={40}
                  className="rounded-lg"
                />
                <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                  Kimeoro Bot
                </span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                El panel de administración más completo para bots de Discord. 
                Gestiona tu comunidad con estilo.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Enlaces Rápidos</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Panel</a></li>
                <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Documentación</a></li>
                <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">API Status</a></li>
                <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">Soporte</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Comunidad</h4>
              <ul className="space-y-2">
                <li><a href="https://discord.gg/kimeoro" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-indigo-400 transition-colors text-sm flex items-center gap-2"><MessageCircle className="w-4 h-4" /> Discord</a></li>
                <li><a href="#" className="text-gray-400 hover:text-purple-400 transition-colors text-sm flex items-center gap-2"><ExternalLink className="w-4 h-4" /> GitHub</a></li>
              </ul>
              
              <div className="mt-6 flex gap-3">
                <a
                  href="https://discord.gg/kimeoro"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all duration-300 flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Discord
                </a>
                <a
                  href="/dashboard"
                  className="px-5 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white text-sm font-semibold transition-all duration-300 flex items-center gap-2"
                >
                  <Bot className="w-4 h-4" />
                  Panel
                </a>
              </div>
            </div>
          </div>

          {/* Legal disclaimer */}
          <div className="mt-8 pt-6 border-t border-purple-900/10">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-gray-600 text-xs text-center">
              <div className="flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5" />
                <span>© 2024 Kimeoro Bot. Todos los derechos reservados.</span>
              </div>
              <span className="hidden sm:inline">|</span>
              <span>No afiliado ni asociado con Discord Inc.</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ─── Main Page ─── */
export default function KimeoroBotPage() {
  return (
    <main className="relative min-h-screen flex flex-col">
      <Starfield />
      <Navbar />
      <div className="relative z-10">
        <HeroSection />
        <FeaturesSection />
        <DashboardSection />
        <ServersSection />
        <MobileServersSection />
        <Footer />
      </div>
    </main>
  );
}
